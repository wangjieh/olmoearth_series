"""Dataset module for OlmoEarth Pretrain."""

from __future__ import annotations

import hashlib
import logging
import shutil
import time
from dataclasses import dataclass
from typing import Any, NamedTuple

import h5py

# hdf5 plugin is needed to decompress the data for certain compression types
import hdf5plugin  # noqa: F401
import numpy as np
import pandas as pd
from olmo_core.data.utils import get_rng
from torch.utils.data import Dataset
from upath import UPath

from olmoearth_pretrain._compat import (
    deprecated_class_alias as _deprecated_class_alias,
)
from olmoearth_pretrain.config import Config
from olmoearth_pretrain.data.constants import (
    MAX_SEQUENCE_LENGTH,
    MISSING_VALUE,
    Modality,
    ModalitySpec,
)
from olmoearth_pretrain.data.normalize import Normalizer, Strategy
from olmoearth_pretrain.dataset.convert_to_h5py import ConvertToH5py
from olmoearth_pretrain.datatypes import (
    OlmoEarthSample,
)
from olmoearth_pretrain.nn.tokenization import TokenizationConfig
from olmoearth_pretrain.types import ArrayTensor

logger = logging.getLogger(__name__)


# =============================================================================
# 性能计时探针（Performance Timing Probes）
# =============================================================================


class _TimingProbe:
    """数据加载管线性能计时探针（原始版本，无缓存命中统计）。

    CSV 输出格式：
        sample_idx,total,h5_read,crop_timestamps,pad_timestamps,fill_missing,subset_sample,ndvi,normalize
        0,0.082,0.035,0.002,0.001,0.030,0.005,0.001,0.008
    """

    def __init__(
        self,
        enabled: bool = True,
        log_interval: int = 100,
        csv_path: str | None = "timing_probe.csv",
    ):
        self._enabled = enabled
        self._log_interval = log_interval
        self._sample_count = 0
        self._cumulative: dict[str, float] = {}
        self._marks: dict[str, float] = {}
        self._current: dict[str, float] = {}
        self._csv_path = csv_path
        self._csv_header_written = False
        self._csv_step_names: list[str] = []
        # 跟踪当前样本中最近一次 tick 的时间，用于链式计时
        self._last_tick_time: float | None = None

    @property
    def enabled(self) -> bool:
        return self._enabled

    def start(self, name: str) -> None:
        if not self._enabled:
            return
        t = time.perf_counter()
        self._marks[name] = t
        self._last_tick_time = t

    def tick(self, name: str, since: str | None = None) -> None:
        if not self._enabled:
            return
        now = time.perf_counter()
        if since is not None:
            elapsed = now - self._marks.get(since, now)
        elif self._last_tick_time is not None:
            elapsed = now - self._last_tick_time
        else:
            elapsed = 0.0
        self._cumulative[name] = self._cumulative.get(name, 0.0) + elapsed
        self._current[name] = elapsed
        self._marks[name] = now
        self._last_tick_time = now

    def end(self, name: str, since: str | None = None) -> None:
        if not self._enabled:
            return
        now = time.perf_counter()
        start_mark = since if since is not None else name
        elapsed = now - self._marks.get(start_mark, now)
        self._cumulative[name] = self._cumulative.get(name, 0.0) + elapsed
        self._current[name] = elapsed

    def record(self) -> None:
        if not self._enabled:
            return
        self._sample_count += 1

        if self._csv_path is not None and self._current:
            import csv as _csv
            import os

            step_names = list(self._current.keys())

            if not self._csv_header_written:
                # 检查文件是否已存在且有内容（跨 epoch 追加）
                file_exists = os.path.exists(self._csv_path) and os.path.getsize(self._csv_path) > 0
                csv_dir = os.path.dirname(self._csv_path)
                if csv_dir and not os.path.exists(csv_dir):
                    os.makedirs(csv_dir, exist_ok=True)
                if not file_exists:
                    # 文件不存在或为空，写入 header
                    with open(self._csv_path, "w", newline="") as f:
                        writer = _csv.writer(f)
                        writer.writerow(["sample_idx"] + step_names)
                self._csv_header_written = True
                self._csv_step_names = step_names

            with open(self._csv_path, "a", newline="") as f:
                writer = _csv.writer(f)
                row = [self._sample_count - 1]
                for step in self._csv_step_names:
                    row.append(f"{self._current.get(step, 0.0):.6f}")
                writer.writerow(row)

        if self._sample_count % self._log_interval == 0:
            parts = [f"samples={self._sample_count}"]
            for name, total in self._cumulative.items():
                avg = total / self._log_interval
                parts.append(f"{name}={avg:.4f}s")
            logger.info(f"[TimingProbe] {', '.join(parts)}")
            self._cumulative.clear()


# =============================================================================
# Subsetting Functions
# =============================================================================


def _get_max_t_within_token_budget(
    sample: OlmoEarthSample,
    h_w_p: int,
    max_tokens_per_instance: int,
    tokenization_config: TokenizationConfig | None = None,
) -> int:
    """Find max t possible when subsetting.

    Given a sampled h_w_p (the number of tokens along the h and w dimensions)
    return the maximum t allowed within the max_tokens budget so that the
    patchified OlmoEarthSample will have fewer than max_tokens tokens.

    This function assumes we apply (H, W, T=1 patchifying)
    """
    from math import floor

    used_tokens = 0
    time_multiply_tokens = 0
    for attribute in sample.as_dict().keys():
        if attribute in ("timestamps", "latlon"):
            continue
        modality_spec = Modality.get(attribute)
        num_band_sets = (
            tokenization_config.get_num_bandsets(attribute)
            if tokenization_config is not None
            else modality_spec.num_band_sets
        )
        if modality_spec.is_spacetime_varying:
            time_multiply_tokens += (h_w_p**2) * num_band_sets
        elif modality_spec.is_space_only_varying:
            used_tokens += (h_w_p**2) * num_band_sets
        elif modality_spec.is_time_only_varying:
            time_multiply_tokens += num_band_sets
        elif modality_spec.is_static_in_space_and_time:
            used_tokens += num_band_sets
    if time_multiply_tokens == 0:
        return 1
    remaining_tokens = max_tokens_per_instance - used_tokens
    max_t_within_budget = remaining_tokens / time_multiply_tokens
    if max_t_within_budget < 1:
        raise ValueError(
            f"patch_size too small for this sample and budget, h_w_p: {h_w_p}, max_tokens: {max_tokens_per_instance}"
        )

    return min(floor(max_t_within_budget), sample.time)


def get_valid_start_ts(
    missing_timesteps: dict[str, Any], max_t: int, current_length: int
) -> list[int]:
    """Get valid starting timesteps."""
    if current_length > max_t:
        if not missing_timesteps:
            valid_start_ts = list(range(current_length - max_t + 1))
        else:
            start_ts = set()
            for modality in missing_timesteps:
                valid_timesteps = np.flatnonzero(missing_timesteps[modality])
                valid_timesteps = valid_timesteps[
                    valid_timesteps + max_t <= current_length
                ]
                start_ts.update(valid_timesteps)
            valid_start_ts = list(start_ts)
    else:
        valid_start_ts = [0]
    if len(valid_start_ts) == 0:
        logger.warning(
            f"No valid start timesteps found for {missing_timesteps} with max_t {max_t} and current_length {current_length}"
        )
        raise ValueError(
            f"No valid start timesteps found for {missing_timesteps} with max_t {max_t} and current_length {current_length}"
        )
    return sorted(valid_start_ts)


def subset_sample_default(
    sample: OlmoEarthSample,
    patch_size: int,
    max_tokens_per_instance: int | None,
    sampled_hw_p: int,
    current_length: int,
    missing_timesteps_masks: dict[str, Any] | None = None,
    tokenization_config: TokenizationConfig | None = None,
) -> OlmoEarthSample:
    """Subset a OlmoEarthSample using default rectangular cropping.

    Args:
        sample: The sample to subset.
        patch_size: The patch size being applied to this sample.
        max_tokens_per_instance: The token budget when subsetting. This is used
            to determine the maximum number of timesteps possible for a given
            height and width. If None, this operation is a no-op.
        sampled_hw_p: The number of tokens in the height and width dimensions.
        current_length: The current maximum sequence length of the sample.
        missing_timesteps_masks: A dictionary of missing timesteps masks.
        tokenization_config: Optional tokenization config for custom band groupings.

    Returns:
        A subsetted OlmoEarthSample with rectangular cropping applied.
    """
    if max_tokens_per_instance is None:
        return sample
    if missing_timesteps_masks is None:
        missing_timesteps_masks = {}

    max_t = _get_max_t_within_token_budget(
        sample, sampled_hw_p, max_tokens_per_instance, tokenization_config
    )
    max_t = min(max_t, MAX_SEQUENCE_LENGTH)
    valid_start_ts = get_valid_start_ts(missing_timesteps_masks, max_t, current_length)
    start_t = np.random.choice(valid_start_ts)
    new_data_dict: dict[str, ArrayTensor] = {}

    sampled_hw = sampled_hw_p * patch_size
    start_h = np.random.choice(sample.height - sampled_hw + 1)
    start_w = np.random.choice(sample.width - sampled_hw + 1)

    for attribute, modality in sample.as_dict().items():
        assert modality is not None
        if attribute == "timestamps":
            new_data_dict[attribute] = modality[start_t : start_t + max_t]
            continue
        if attribute == "latlon":
            new_data_dict[attribute] = modality
            continue
        modality_spec = Modality.get(attribute)
        if modality_spec.is_spacetime_varying:
            new_data_dict[attribute] = modality[
                start_h * modality_spec.image_tile_size_factor : (start_h + sampled_hw)
                * modality_spec.image_tile_size_factor,
                start_w * modality_spec.image_tile_size_factor : (start_w + sampled_hw)
                * modality_spec.image_tile_size_factor,
                start_t : start_t + max_t,
            ]
        elif modality_spec.is_space_only_varying:
            new_data_dict[attribute] = modality[
                start_h * modality_spec.image_tile_size_factor : (start_h + sampled_hw)
                * modality_spec.image_tile_size_factor,
                start_w * modality_spec.image_tile_size_factor : (start_w + sampled_hw)
                * modality_spec.image_tile_size_factor,
            ]
        elif modality_spec.is_time_only_varying:
            new_data_dict[attribute] = modality[start_t : start_t + max_t]
        elif modality_spec.is_static_in_space_and_time:
            new_data_dict[attribute] = modality

    return OlmoEarthSample(**new_data_dict)


def subset_sample_cutmix(
    sample: OlmoEarthSample,
    patch_size: int,
    max_tokens_per_instance: int | None,
    sampled_hw_p: int,
    current_length: int,
    missing_timesteps_masks: dict[str, Any] | None = None,
    tokenization_config: TokenizationConfig | None = None,
) -> OlmoEarthSample:
    """Subset a OlmoEarthSample using CutMix patch sampling.

    Args:
        sample: The sample to subset.
        patch_size: The patch size being applied to this sample.
        max_tokens_per_instance: The token budget when subsetting. This is used
            to determine the maximum number of timesteps possible for a given
            height and width. If None, this operation is a no-op.
        sampled_hw_p: The number of tokens in the height and width dimensions.
        current_length: The current maximum sequence length of the sample.
        missing_timesteps_masks: A dictionary of missing timesteps masks.
        tokenization_config: Optional tokenization config for custom band groupings.

    Returns:
        A subsetted OlmoEarthSample with CutMix patch sampling applied.
    """
    if max_tokens_per_instance is None:
        return sample
    if missing_timesteps_masks is None:
        missing_timesteps_masks = {}

    max_t = _get_max_t_within_token_budget(
        sample, sampled_hw_p, max_tokens_per_instance, tokenization_config
    )
    valid_start_ts = get_valid_start_ts(missing_timesteps_masks, max_t, current_length)
    start_t = np.random.choice(valid_start_ts)
    new_data_dict: dict[str, ArrayTensor] = {}

    height_p, width_p = sample.height // patch_size, sample.width // patch_size
    h_p_indices = np.random.choice(height_p, size=sampled_hw_p, replace=False)
    w_p_indices = np.random.choice(width_p, size=sampled_hw_p, replace=False)
    h_indices = [
        i
        for h_p in h_p_indices
        for i in range(h_p * patch_size, (h_p + 1) * patch_size)
    ]
    w_indices = [
        i
        for w_p in w_p_indices
        for i in range(w_p * patch_size, (w_p + 1) * patch_size)
    ]
    hh, ww = np.meshgrid(h_indices, w_indices, indexing="ij")

    for attribute, modality in sample.as_dict().items():
        assert modality is not None
        if attribute == "timestamps":
            new_data_dict[attribute] = modality[start_t : start_t + max_t]
            continue
        if attribute == "latlon":
            new_data_dict[attribute] = modality
            continue
        modality_spec = Modality.get(attribute)
        if modality_spec.is_spacetime_varying:
            new_data_dict[attribute] = modality[
                hh * modality_spec.image_tile_size_factor,
                ww * modality_spec.image_tile_size_factor,
                start_t : start_t + max_t,
            ]
        elif modality_spec.is_space_only_varying:
            new_data_dict[attribute] = modality[
                hh * modality_spec.image_tile_size_factor,
                ww * modality_spec.image_tile_size_factor,
            ]
        elif modality_spec.is_time_only_varying:
            new_data_dict[attribute] = modality[start_t : start_t + max_t]
        elif modality_spec.is_static_in_space_and_time:
            new_data_dict[attribute] = modality

    return OlmoEarthSample(**new_data_dict)


class GetItemArgs(NamedTuple):
    """Arguments for the __getitem__ method of the OlmoEarthDataset."""

    idx: int
    patch_size: int
    sampled_hw_p: int
    token_budget: int | None = None
    tokenization_config: TokenizationConfig | None = None


# TODO should training modalities be str or modality_spec
class OlmoEarthDataset(Dataset):
    """OlmoEarth Pretrain dataset.
    OlmoEarth 预训练数据集。
    
    为什么这个类有这么多处理函数?
    
    地球观测数据具有以下复杂性,需要大量预处理才能用于模型训练:
    
    1. **多模态异构性**: 
       - 不同传感器(Sentinel-2, Landsat, NAIP等)有不同的分辨率、波段数、数据格式
       - 需要将它们统一到一致的张量结构中
    
    2. **时空不规则性**:
       - 卫星过境时间不规律,存在缺失的时间步
       - 云层遮挡导致某些时间点数据不可用
       - 需要填充缺失值并保持时间对齐
    
    3. **数据规模巨大**:
       - 原始卫星图像可达数千像素宽高
       - 需要随机裁剪(patch)以适应模型输入尺寸和token预算
       - 支持CutMix等数据增强策略
    
    4. **数值范围差异**:
       - 不同模态的像素值范围差异很大(如反射率0-1 vs DN值0-65535)
       - 需要归一化到统一范围以便模型学习
    
    5. **I/O优化需求**:
       - HDF5文件可能存储在远程存储(S3/GCS),读取延迟高
       - 需要本地缓存、读取限流等机制优化性能
    
    6. **数据质量控制**:
       - 过滤掉不包含所需模态的样本
       - 支持只使用部分数据进行快速实验
    
    因此,这个类封装了从原始HDF5文件到模型可用样本的完整转换流程。
    """

    def __init__(
        self,
        h5py_dir: UPath,
        training_modalities: list[str],
        dtype: np.dtype,
        max_sequence_length: int = MAX_SEQUENCE_LENGTH,
        normalize: bool = True,
        cache_dir: UPath | None = None,
        samples_per_sec: float | None = None,
        dataset_percentage: float = 1.0,
        seed: int = 0,
        apply_cutmix: bool = False,
        filter_idx_file: str | None = None,
    ):
        """Initialize the dataset.

        To use an already created h5py directory, set h5py_dir to the path of the h5py directory.
        To use a raw tile directory, set tile_path to the path of the tile directory, this will create the h5py files in a prepare step before training.
        Warning from OLMo-core:
            In distributed settings, be sure that the :data:`work_dir` is shared among all local ranks
            and :data:`fs_local_rank` is set accordingly. Once those fields are set you should then call
            :meth:`prepare()` in the main process before doing anything else.

        Args:
            h5py_dir: The path to the h5py directory containing preprocessed data.
            training_modalities: The modalities to use for training.
            dtype: The dtype of the data.
            max_sequence_length: The maximum sequence length that we pad all time dimensions to.
            normalize: If True, apply normalization to the data, if False, do not apply
                normalization.
            cache_dir: optional local directory to cache the H5 files.
            samples_per_sec: throttle to reading this many samples per second. This
                throttling only applies when reading from the h5py_dir, not the
                cache_dir (if set).
            dataset_percentage: The percentage of the dataset to use.
            seed: For selecting the dataset percentage.
            apply_cutmix: Whether or not to apply CutMix augmentation during subsetting.
            filter_idx_file: If not None, filters indices by the values in this numpy array

        Returns:
            None
        """
        self.h5py_dir = h5py_dir
        if not self.h5py_dir.exists():
            raise FileNotFoundError(f"H5PY directory does not exist: {self.h5py_dir}")
        self.cache_dir = cache_dir
        if self.cache_dir is not None:
            self.cache_dir.mkdir(parents=True, exist_ok=True)

        self.training_modalities = training_modalities

        self.dtype = dtype
        self.normalize = normalize
        self.dataset_percentage = dataset_percentage
        self.seed = seed
        if self.normalize:
            self.normalizer_predefined = Normalizer(Strategy.PREDEFINED)
            self.normalizer_computed = Normalizer(Strategy.COMPUTED)
        self.max_sequence_length = max_sequence_length

        if samples_per_sec is None:
            self.sec_per_sample = None
        else:
            self.sec_per_sample = 1 / samples_per_sec
        self.last_read_time = time.time()

        self.sample_indices: np.ndarray | None = None
        self.latlon_distribution: np.ndarray | None = None
        self.apply_cutmix = apply_cutmix
        self.filter_idx_file = filter_idx_file
        if filter_idx_file is not None:
            self.indices_to_filter: np.ndarray | None = np.load(filter_idx_file)
            assert isinstance(self.indices_to_filter, np.ndarray), (
                f"Expected filter_idx_file to point to a np.ndarray, got {type(self.indices_to_filter)} instead."
            )
        else:
            self.indices_to_filter = None

        # 性能计时探针
        import os
        worker_id = os.getpid()
        csv_path = f"timing_probe_dataset_ori_w{worker_id}.csv"
        self._timing_probe = _TimingProbe(enabled=False, log_interval=100, csv_path=csv_path)

    @property
    def fingerprint_version(self) -> str:
        """The version of the fingerprint."""
        return "v0.1"

    @property
    def fingerprint(self) -> str:
        """Can be used to identify/compare a dataset."""
        if not self.is_dataset_prepared:
            raise RuntimeError("Dataset must be prepared before creating a fingerprint")
        sha256_hash = hashlib.sha256()
        # Parse from the h5py_dir
        supported_modalities_folder = self.h5py_dir.parent.name
        supported_modalities = supported_modalities_folder.split("_")
        # join back sentinel_l2a and openstreetmap_raster if applicable
        if "l2a" in supported_modalities:
            supported_modalities.remove("l2a")
            supported_modalities.remove("sentinel2")
            supported_modalities.append("sentinel2_l2a")
        if "raster" in supported_modalities:
            supported_modalities.remove("raster")
            supported_modalities.remove("openstreetmap")
            supported_modalities.append("openstreetmap_raster")

        if "naip" in supported_modalities and "10" in supported_modalities:
            supported_modalities.remove("naip")
            supported_modalities.remove("10")
            supported_modalities.append("naip_10")
            
        if "landcover" in supported_modalities and "1m" in supported_modalities:
            supported_modalities.remove("landcover")
            supported_modalities.remove("1m")
            supported_modalities.append("landcover_1m")

        if "landcover" in supported_modalities and "30m" in supported_modalities:
            supported_modalities.remove("landcover")
            supported_modalities.remove("30m")
            supported_modalities.append("landcover_30m")
        # latlons are saved with every h5py file, see
        # olmoearth_pretrain.dataset.convert_to_h5py.ConvertToH5py._create_h5_file
        supported_modalities.append("latlon")
        num_samples = int(self.h5py_dir.name)

        tile_path = self.h5py_dir.parent.parent.parent

        if self.filter_idx_file is not None:
            filter_file_string = f",filter_idx_file={self.filter_idx_file}"
        else:
            filter_file_string = ""

        sha256_hash.update(
            f"tile_path={tile_path},"
            f"supported_modalities={sorted(supported_modalities)},"
            f"sample_size={num_samples},"
            f"dtype={self.dtype}"
            f"{filter_file_string}".encode()
        )
        return sha256_hash.hexdigest()

    @property
    def sample_metadata_path(self) -> UPath:
        """Get the path to the sample metadata file."""
        return self.h5py_dir / ConvertToH5py.sample_metadata_fname

    @property
    def latlon_distribution_path(self) -> UPath:
        """Get the path to the latlon distribution file."""
        return self.h5py_dir / ConvertToH5py.latlon_distribution_fname

    @property
    def is_dataset_prepared(self) -> bool:
        """Check if the dataset is prepared."""
        return self.sample_indices is not None

    def _filter_sample_indices_for_training(self) -> None:
        """Filter the sample indices for training.

        Updates the sample indices numpy array to only include the indices we want to train on.
        【数据质量控制】过滤训练样本索引。
        
        目的: 移除不包含所需时空变化模态的无效样本。
        
        为什么需要:
        - 某些地理位置可能缺少特定传感器数据(如云层覆盖、传感器故障)
        - 如果训练配置要求使用Sentinel-2,但该位置没有S2数据,这个样本就没用
        - 避免在训练时遇到空数据或错误
        
        工作流程:
        1. 读取metadata CSV,查看每个样本有哪些模态可用
        2. 找出所有时空变化模态都为空的样本索引
        3. 从sample_indices中排除这些无效样本
        4. 如果指定了filter_idx_file,进一步取交集
        """
        # Read the metadata CSV
        # TODO: Pandas can't read gcs upaths
        metadata_df = pd.read_csv(str(self.sample_metadata_path))
        logger.info(f"Metadata CSV has {len(metadata_df)} samples")
        logger.info(f"columns: {metadata_df.columns}")

        # Get the indices of samples that don't have any training modalities that are
        # spacetime varying. We want to remove these samples.
        # Skip derived modalities (ignore_when_parsing=True) since they don't have
        # columns in the metadata CSV.
        spacetime_varying_training_modalities = [
            modality
            for modality in self.training_modalities
            if Modality.get(modality).is_spacetime_varying
            and not Modality.get(modality).ignore_when_parsing
        ]
        if len(spacetime_varying_training_modalities) == 0:
            raise ValueError(
                "no spacetime varying modalities are specified for training"
            )
        no_spacetime_varying_indices = metadata_df[
            metadata_df[spacetime_varying_training_modalities].sum(axis=1) == 0
        ].index

        # Filter these indices out
        logger.info(
            f"Filtering out {len(no_spacetime_varying_indices)} samples without any training modalities"
        )
        self.sample_indices = np.setdiff1d(
            self.sample_indices, no_spacetime_varying_indices
        )
        logger.info(
            f"Filtered {len(no_spacetime_varying_indices)} samples to {self.sample_indices.shape} samples"
        )
        if self.indices_to_filter is not None:
            self.sample_indices = np.intersect1d(
                self.sample_indices, self.indices_to_filter
            )

            logger.info(
                f"Intersected {len(self.indices_to_filter)} samples to yield {self.sample_indices.shape} samples"
            )

    def _filter_sample_indices_by_dataset_percentage(self) -> None:
        """Filter the sample indices for dataset percentage.
        【实验加速】按百分比筛选样本索引。
        
        目的: 只使用数据集的一部分进行训练,用于快速实验或消融研究。
        
        为什么需要:
        - 完整数据集可能包含数百万样本,训练耗时极长
        - 调试代码时只需少量样本验证逻辑正确性
        - 研究数据量对模型性能的影响(缩放定律)
        
        示例: dataset_percentage=0.1 表示只使用10%的数据
        """
        assert self.sample_indices is not None, (
            "Sample indices must be set before filtering by dataset percentage"
        )
        if self.dataset_percentage < 1.0:
            rng = get_rng(self.seed)
            num_samples = len(self.sample_indices)
            self.sample_indices = rng.choice(
                self.sample_indices,
                size=int(len(self.sample_indices) * self.dataset_percentage),
                replace=False,
            )
            logger.info(
                f"Picked {len(self.sample_indices)} samples from {num_samples} samples"
            )

    def prepare(self) -> None:
        """Prepare the dataset.

        THIS SHOULD BE CALLED BY THE MAIN PROCESS ONLY and should happen
        before any other process tries to use the dataset
        """
        logger.info("Preparing dataset...")
        if self.is_dataset_prepared:
            logger.info("Dataset is already prepared")
            return

        num_samples = int(self.h5py_dir.name)
        self.latlon_distribution = self.get_geographic_distribution()
        self.sample_indices = np.arange(num_samples)
        self._filter_sample_indices_for_training()
        self._filter_sample_indices_by_dataset_percentage()
        self.latlon_distribution = self.latlon_distribution[self.sample_indices]

    def get_geographic_distribution(self) -> np.ndarray:
        """Get the geographic distribution of the dataset.

        Returns:
            numpy.ndarray: Array of shape (N, 2) containing [latitude, longitude]
            coordinates for each of the N samples in the dataset.
        """
        if self.latlon_distribution_path.exists():
            with self.latlon_distribution_path.open("rb") as f:
                return np.load(f)

    def __len__(self) -> int:
        """Get the length of the dataset."""
        if self.sample_indices is None:
            raise ValueError("Dataset is not prepared")
        return self.sample_indices.shape[0]

    def normalize_image(self, modality: ModalitySpec, image: np.ndarray) -> np.ndarray:
        """Normalize the image.
        【数据归一化】对图像数据进行标准化。
        
        目的: 将不同模态的像素值缩放到统一范围,便于模型学习。
        
        为什么需要:
        - Sentinel-2反射率范围: 0-1
        - Landsat DN值范围: 0-65535
        - NAIP RGB值范围: 0-255
        - 如果不归一化,模型会偏向数值范围大的模态
        
        策略:
        1. 优先使用COMPUTED策略(基于数据统计动态计算均值/标准差)
        2. 如果失败,回退到PREDEFINED策略(使用预设的统计值)
        """
        # Try computed strategy first, if it fails, try predefined strategy
        # TODO: we can also make modality norm strategy configurable later
        try:
            return self.normalizer_computed.normalize(modality, image)
        except Exception:
            return self.normalizer_predefined.normalize(modality, image)

    def _compute_ndvi(
        self,
        s2_data: np.ndarray,
        missing_modalities: list[str],
    ) -> tuple[np.ndarray, list[str]]:
        """
        Compute NDVI from raw Sentinel-2 L2A bands.

        NDVI = (NIR - Red) / (NIR + Red) where NIR=B08 (index 3) and Red=B04 (index 2).
        If either band has MISSING_VALUE at a pixel, NDVI is set to MISSING_VALUE there.

        Args:
            s2_data: Raw (un-normalized) S2 L2A data, shape [H, W, T, C].
            missing_modalities: List of modalities that are entirely missing.

        Returns:
            Tuple of (ndvi array [H, W, T, 1], updated missing_modalities).
        
        【特征工程】从Sentinel-2原始波段计算NDVI植被指数。
        
        目的: 将原始多光谱数据转换为更有意义的语义特征。
        
        为什么需要:
        - NDVI (归一化植被指数) 是遥感中最重要的植被指标之一
        - 公式: NDVI = (NIR - Red) / (NIR + Red)
        - 模型直接学习NDVI比学习原始B04/B08波段更高效
        
        注意事项:
        - 如果NIR或Red波段有缺失值,NDVI也标记为缺失
        - 防止除零错误: 分母接近0时使用安全值
        - 计算后从missing_modalities列表中移除"ndvi"
        """
        s2_band_order = Modality.SENTINEL2_L2A.band_order
        red = s2_data[..., s2_band_order.index("B04")]
        nir = s2_data[..., s2_band_order.index("B08")]

        missing = (red == MISSING_VALUE) | (nir == MISSING_VALUE)

        denom = nir + red
        safe_denom = np.where(np.abs(denom) < 1e-10, 1.0, denom)
        ndvi = (nir - red) / safe_denom
        ndvi = np.where(np.abs(denom) < 1e-10, 0.0, ndvi)
        ndvi = np.where(missing, MISSING_VALUE, ndvi)

        # Remove "ndvi" from missing_modalities since we computed it
        updated_missing = [m for m in missing_modalities if m != "ndvi"]
        return ndvi[..., np.newaxis].astype(self.dtype), updated_missing

    def _fill_missing_timesteps(
        self,
        modality_data: np.ndarray,
        missing_timestep_mask: np.ndarray,
    ) -> np.ndarray:
        """
        Fill the missing timesteps with the missing value.
        【时间对齐】填充缺失的时间步。

        目的: 确保所有样本具有相同的时间维度长度(max_sequence_length)。

        为什么需要:
        - 卫星过境时间不规律: 某地可能有12个时间点,另一地只有9个
        - PyTorch的torch.stack要求所有张量维度完全一致
        - 缺失的时间步用MISSING_VALUE填充,并通过mask标记

        工作流程:
        1. 创建形状为(H, W, max_sequence_length, C)的全缺失值数组
        2. 根据mask找到有效时间步的索引
        3. 将实际数据复制到对应位置
        4. 其余位置保持MISSING_VALUE

        示例:
        - 原始数据: t=[0,1,2] (3个时间步)
        - max_sequence_length: 12
        - mask: [True, False, True, True, ...] (第1,3,4步有效)
        - 结果: 在位置1,3,4填入数据,其余为MISSING_VALUE
        """
        # 仅在类型不匹配时才转换，避免不必要的完整副本
        if modality_data.dtype != self.dtype:
            modality_data = modality_data.astype(self.dtype)
        # Get the shape of the data to create properly sized temporal layers
        h, w, t, c = modality_data.shape

        # 快速路径1：如果所有时间步都有效且长度已匹配，直接返回
        if t == self.max_sequence_length and np.all(missing_timestep_mask):
            return modality_data

        # 快速路径2：如果所有时间步都有效但需要填充
        if np.all(missing_timestep_mask[:t]) and t < self.max_sequence_length:
            full_timesteps_data = np.full(
                (h, w, max(self.max_sequence_length, missing_timestep_mask.shape[0]), c),
                MISSING_VALUE,
                dtype=self.dtype,
            )
            full_timesteps_data[:, :, :t, :] = modality_data
            return full_timesteps_data

        # 慢路径：存在缺失时间步
        full_timesteps_data = np.full(
            (h, w, max(self.max_sequence_length, missing_timestep_mask.shape[0]), c),
            MISSING_VALUE,
            dtype=self.dtype,
        )

        # Copy the existing data to the appropriate timestep positions
        present_indices = np.where(missing_timestep_mask)[0]
        num_to_copy = min(len(present_indices), t)
        if num_to_copy > 0:
            # 优化：如果有效索引是连续的，使用切片替代高级索引（切片比fancy indexing快得多）
            idx_diff = np.diff(present_indices[:num_to_copy])
            if num_to_copy == 1 or np.all(idx_diff == 1):
                start_idx = present_indices[0]
                end_idx = start_idx + num_to_copy
                full_timesteps_data[:, :, start_idx:end_idx, :] = modality_data[
                    :, :, :num_to_copy, :
                ]
            else:
                full_timesteps_data[:, :, present_indices[:num_to_copy], :] = modality_data[
                    :, :, :num_to_copy, :
                ]

        return full_timesteps_data

    def _fill_missing_modality(
        self, modality: str, height: int | None, width: int | None, time: int
    ) -> np.ndarray:
        """
        Fill an array of shape of modality with the missing value.
        【模态补全】为完全缺失的模态创建全缺失值数组。
        
        目的: 当某个模态在整个样本中都不存在时,用MISSING_VALUE填充。
        
        为什么需要:
        - 训练配置可能要求使用10种模态,但某地只有其中7种
        - 例如: 海洋区域没有CDL(作物类型)数据
        - 必须保持所有样本的模态结构一致,否则无法组成batch
        
        示例:
        - 训练模态: [sentinel2, landsat, cdl, srtm, ...]
        - 某样本只有sentinel2和srtm
        - cdl、landsat等需要用MISSING_VALUE填充对应形状的数组
        """
        expected_shape = OlmoEarthSample.compute_expected_shape(
            modality, height, width, time
        )
        logger.debug(f"Filling {modality} with shape {expected_shape}")
        return np.full(
            expected_shape,
            fill_value=MISSING_VALUE,
            dtype=self.dtype,
        )

    @staticmethod
    def extract_hwt_from_sample_dict(
        sample_dict: dict[str, Any],
    ) -> tuple[int, int, int]:
        """Extract h, w, t from sample_dict."""
        time = sample_dict["timestamps"].shape[0]
        for mod_name, mod_data in sample_dict.items():
            if mod_name == "timestamps":
                continue
            mod_spec = Modality.get(mod_name)
            if mod_spec.is_spatial and mod_data is not None:
                # shape is (H, W, T, C) without batch dim
                height = mod_data.shape[0] // mod_spec.image_tile_size_factor
                width = mod_data.shape[1] // mod_spec.image_tile_size_factor
                return height, width, time
        raise ValueError("Expected sample dict to have at least one spatial modality")

    def fill_sample_with_missing_values(
        self, sample_dict: dict[str, Any], missing_timesteps_masks: dict[str, Any]
    ) -> tuple[OlmoEarthSample, list[str]]:
        """
        Fill the sample with missing values.
        【数据完整性】填充样本中的所有缺失值。
        
        目的: 确保返回的样本包含所有训练所需的模态,且时间维度对齐。
        
        为什么这是核心函数:
        - 协调调用_fill_missing_modality和_fill_missing_timesteps
        - 处理两种缺失情况:
          1. 整个模态缺失 → 创建全MISSING_VALUE数组
          2. 部分时间步缺失 → 在正确位置填充数据,其余用MISSING_VALUE
        
        返回值:
        - OlmoEarthSample: 完整的样本对象
        - missing_modalities: 完全缺失的模态列表(用于跳过归一化)
        """
        # 【修改点1】：允许时间步长大于等于max_sequence_length
        current_time_len = sample_dict["timestamps"].shape[0]
        assert current_time_len >= self.max_sequence_length, (
            f"Timestamps shape {sample_dict['timestamps'].shape[0]} does not match max_sequence_length {self.max_sequence_length}"
        )
        missing_modalities = []

        height, width, time = self.extract_hwt_from_sample_dict(sample_dict)

        for modality in self.training_modalities:
            # If one modality is completely missing, we need to fill it all with missing values
            if modality not in sample_dict.keys():
                logger.debug(f"Filling {modality} with missing values")
                sample_dict[modality] = self._fill_missing_modality(
                    modality, height, width, time
                )
                missing_modalities.append(modality)
                continue

            # For multi-temporal modalities, we need to handle missing timesteps
            # The missing_timesteps_masks indicates which timesteps are present (True) or missing (False)
            if modality in missing_timesteps_masks:
                mask = missing_timesteps_masks[modality]
                modality_data = sample_dict[modality]

                # 快速路径：如果所有时间步都有效且长度已匹配，仅做类型转换
                if len(mask) == self.max_sequence_length and np.all(mask):
                    if modality_data.dtype != self.dtype:
                        sample_dict[modality] = modality_data.astype(self.dtype)
                    continue

                # 仅在类型不匹配时才转换，避免不必要的完整副本
                if modality_data.dtype != self.dtype:
                    modality_data = modality_data.astype(self.dtype)

                # As long as the #timesteps is less than the max_sequence_length, we will impute by missing value
                has_missing_timesteps = (
                    not np.all(mask) or len(mask) < self.max_sequence_length
                )
                if has_missing_timesteps:
                    # By default, we will fill missing timesteps with the missing value
                    modality_data = self._fill_missing_timesteps(modality_data, mask)
                # Update the sample dictionary with the potentially imputed data
                sample_dict[modality] = modality_data
        return OlmoEarthSample(**sample_dict), missing_modalities

    def _pad_timestamps(
        self, sample_dict: dict[str, Any]
    ) -> tuple[dict[str, Any], int]:
        """
        Pad the timestamps to the max_sequence_length.
        【时间维度扩展】将时间戳填充到最大序列长度。
        
        目的: 确保timestamps数组长度与max_sequence_length一致。
        
        为什么需要:
        - 原始HDF5文件中可能只存储了有效的时间步(如9个)
        - 但模型期望输入固定长度(如12个时间步)
        - 使用"edge"模式填充: 复制最后一个时间戳
        
        返回值:
        - 填充后的sample_dict
        - current_length: 原始时间步数(用于后续子集采样)
        """
        timestamps_data = sample_dict["timestamps"]
        current_length = timestamps_data.shape[0]
        if current_length < self.max_sequence_length:
            pad_width = ((0, self.max_sequence_length - current_length), (0, 0))
            # We pad at the end with copies of the last timestep
            padded_timestamps = np.pad(
                timestamps_data, pad_width=pad_width, mode="edge"
            )
            sample_dict["timestamps"] = padded_timestamps
        return sample_dict, current_length

    def _apply_throttling(self) -> None:
        """
        Apply read throttling.

        This function is called when reading a sample from the h5py_dir, and it applies
        the configured throttling.
        【I/O优化】应用读取限流控制。
        
        目的: 控制数据读取速度,避免对共享存储系统造成过载。
        
        为什么需要:
        - 在分布式训练中,多个worker可能同时从NFS/S3读取数据
        - 过高的并发读取会导致存储系统性能下降甚至崩溃
        - 通过sleep控制每秒读取的样本数(samples_per_sec)
        
        工作流程:
        1. 计算自上次读取以来经过的时间
        2. 如果速度快于限制,则sleep剩余时间
        3. 更新last_read_time
        
        注意: 仅对h5py_dir生效,cache_dir不限制(本地磁盘更快)
        """
        if self.sec_per_sample is None:
            return
        elapsed = time.time() - self.last_read_time
        time_to_sleep = self.sec_per_sample - elapsed
        self.last_read_time = time.time()
        logger.info(f"{elapsed} elapsed since last read, sleeping for {time_to_sleep}")
        if time_to_sleep <= 0:
            return
        time.sleep(time_to_sleep)

    def read_h5_file(
        self, h5_file_path: UPath
    ) -> tuple[dict[str, Any], dict[str, Any]]:
        """
        Read the h5 file.
        【核心I/O】读取HDF5文件并提取数据。
        
        目的: 从HDF5文件中加载样本数据和缺失时间步掩码。
        
        为什么这是关键函数:
        - 所有训练数据都存储在HDF5格式中(高效压缩、随机访问)
        - 需要处理远程存储缓存和并发安全问题
        
        工作流程:
        1. **缓存机制**: 
           - 如果设置了cache_dir,先将远程文件复制到本地
           - 使用原子重命名(tmp→正式)避免并发写入冲突
           - 后续读取直接使用本地副本,速度提升10-100倍
        
        2. **限流控制**: 调用_apply_throttling防止存储过载
        
        3. **数据提取**:
           - 读取training_modalities指定的模态数据
           - 读取timestamps时间戳
           - 读取missing_timesteps_masks(标记哪些时间步有效)
        
        返回值:
        - sample_dict: {模态名: numpy数组}
        - missing_timesteps_masks: {模态名: 布尔数组}
        
        性能优化:
        - 使用hdf5plugin支持zstd等压缩算法
        - 本地缓存避免重复网络传输
        """
        if self.cache_dir is not None:
            cache_file_path = self.cache_dir / h5_file_path.name
            logger.debug(f"Caching H5 file {h5_file_path} to {cache_file_path}")
            if not cache_file_path.exists():
                self._apply_throttling()
                # Copy to a temp file first and then atomically rename it to avoid
                # concurrency issues.
                tmp_file_path = self.cache_dir / (h5_file_path.name + ".tmp")
                with h5_file_path.open("rb") as src, tmp_file_path.open("wb") as dst:
                    shutil.copyfileobj(src, dst)
                tmp_file_path.rename(cache_file_path)
            h5_file_path = cache_file_path

        else:
            self._apply_throttling()

        sample_dict = {}
        with h5_file_path.open("rb") as f:
            with h5py.File(f, "r") as h5file:
                logger.debug(
                    f"Reading h5 file {h5_file_path} with keys {h5file.keys()}"
                )
                # timestamps should not be a floating string
                sample_dict = {
                    k: v[()]
                    for k, v in h5file.items()
                    if k in self.training_modalities
                    # TODO: Fix the floating string issue
                    or k in ["timestamps"]
                }

                if (
                    missing_mask_group_name
                    := ConvertToH5py.missing_timesteps_mask_group_name
                ) in h5file:
                    missing_timesteps_masks = {
                        k: v[()]
                        for k, v in h5file[missing_mask_group_name].items()
                        if k in self.training_modalities
                    }
                else:
                    # To preserve backwards compatibility, we set missing_timesteps_masks to an empty dict if it doesn't exist in file
                    missing_timesteps_masks = {}
        return sample_dict, missing_timesteps_masks

    def _get_h5_file_path(self, index: int) -> UPath:
        """Get the h5 file path."""
        return self.h5py_dir / ConvertToH5py.sample_file_pattern.format(index=index)

    @staticmethod
    def _crop_timestamps_and_masks(
        timestamps: np.ndarray, missing_timesteps_masks: dict[str, Any]
    ) -> tuple[np.ndarray, dict[str, Any]]:
        """Crop the timestamps to the first and last valid timestep of the present modalities.
        【时间裁剪】裁剪时间戳和掩码到有效数据范围。
        
        目的: 移除前后无效的时间步,只保留有实际数据的时间段。
        
        为什么需要:
        - HDF5文件可能存储了完整的时间序列(如12步),但只有中间9步有数据
        - 前后的时间步都是MISSING_VALUE,浪费计算资源
        - 裁剪后可以减少后续处理的计算量
        
        工作流程:
        1. 遍历所有模态的missing_timesteps_masks
        2. 找到第一个和最后一个有效时间步
        3. 裁剪timestamps和所有mask到这个范围
        
        示例:
        - 原始: timestamps=[t0,t1,...,t11], mask=[F,F,T,T,T,T,T,T,T,F,F,F]
        - 裁剪后: timestamps=[t2,...,t8], mask=[T,T,T,T,T,T,T]
        """
        if not missing_timesteps_masks:
            first_valid_timestep = 0
            last_valid_timestep = MAX_SEQUENCE_LENGTH
        else:
            # Timestep masks are the same length as the timestamps
            first_valid_timestep = MAX_SEQUENCE_LENGTH
            last_valid_timestep = 0
            for timestep_mask in missing_timesteps_masks.values():
                valid_timesteps = np.where(timestep_mask)[0]
                if len(valid_timesteps) > 0:
                    first_valid_timestep = min(first_valid_timestep, valid_timesteps[0])
                    last_valid_timestep = max(last_valid_timestep, valid_timesteps[-1])
        timestamps = timestamps[first_valid_timestep : last_valid_timestep + 1]
        for modality, timestep_mask in missing_timesteps_masks.items():
            missing_timesteps_masks[modality] = timestep_mask[
                first_valid_timestep : last_valid_timestep + 1
            ]
        return timestamps, missing_timesteps_masks

    def __getitem__(self, args: GetItemArgs) -> tuple[int, OlmoEarthSample]:
        """Get the sample at the given index.

        【已添加计时探针】在每个关键步骤前后插入 time.perf_counter() 计时点，
        耗时写入 CSV 文件并定期输出日志统计。
        """
        # probe = self._timing_probe
        # probe.start("total")

        if hasattr(self, "sample_indices") and self.sample_indices is not None:
            index = self.sample_indices[args.idx]
        else:
            index = args.idx
        h5_file_path = self._get_h5_file_path(index)

        sample_dict, missing_timesteps_masks = self.read_h5_file(h5_file_path)
        # probe.tick("h5_read")

        timestamps, missing_timesteps_masks = self._crop_timestamps_and_masks(
            sample_dict["timestamps"], missing_timesteps_masks
        )
        sample_dict["timestamps"] = timestamps
        # probe.tick("crop_timestamps")

        sample_dict, current_length = self._pad_timestamps(sample_dict)
        # probe.tick("pad_timestamps")

        # fill sample currently takes like .08 seconds which may bottleneck smaller models
        sample, missing_modalities = self.fill_sample_with_missing_values(
            sample_dict, missing_timesteps_masks
        )
        # probe.tick("fill_missing")

        if self.apply_cutmix:
            subset_sample = subset_sample_cutmix(
                sample,
                patch_size=args.patch_size,
                max_tokens_per_instance=args.token_budget,
                sampled_hw_p=args.sampled_hw_p,
                current_length=current_length,
                missing_timesteps_masks=missing_timesteps_masks,
                tokenization_config=args.tokenization_config,
            )
        else:
            subset_sample = subset_sample_default(
                sample,
                patch_size=args.patch_size,
                max_tokens_per_instance=args.token_budget,
                sampled_hw_p=args.sampled_hw_p,
                current_length=current_length,
                missing_timesteps_masks=missing_timesteps_masks,
                tokenization_config=args.tokenization_config,
            )
        # probe.tick("subset_sample")

        sample_dict = subset_sample.as_dict()

        # Compute NDVI from raw (un-normalized) S2 L2A bands if requested
        if (
            "ndvi" in sample_dict
            and "sentinel2_l2a" in sample_dict
            and "sentinel2_l2a" not in missing_modalities
        ):
            sample_dict["ndvi"], missing_modalities = self._compute_ndvi(
                sample_dict["sentinel2_l2a"], missing_modalities
            )
        # probe.tick("ndvi")

        if self.normalize:
            for modality_name in sample_dict.keys():
                if modality_name == "timestamps":
                    continue
                # DO NOT NORMALIZE MISSING MODALITIES otherwise the MISSING_VALUE will be normalized
                if modality_name in missing_modalities:
                    logger.debug(
                        f"Skipping normalization for {modality_name} because it is in missing_modalities"
                    )
                    continue
                logger.debug(f"Normalizing {modality_name}")
                modality_data = sample_dict[modality_name]
                missing_mask = modality_data == MISSING_VALUE
                normalized_data = self.normalize_image(
                    Modality.get(modality_name), modality_data
                )
                # Sentinel Values must be reset after normalization so they can be recognized by missing mask
                sample_dict[modality_name] = np.where(
                    missing_mask, modality_data, normalized_data
                ).astype(self.dtype)
        # probe.tick("normalize")

        # probe.end("total", since="total")
        # probe.record()

        return args.patch_size, OlmoEarthSample(**sample_dict)


@dataclass
class OlmoEarthDatasetConfig(Config):
    """Configuration for the OlmoEarthDataset.
    OlmoEarth数据集配置类。
    
    为什么需要单独的配置类?
    
    1. **解耦配置与实现**: 
       - 配置文件(YAML/JSON) → Config对象 → Dataset实例
       - 便于序列化和分布式传递
    
    2. **类型安全**:
       - dataclass提供自动的类型检查
       - validate方法确保配置合法性
    
    3. **路径处理**:
       - 自动将字符串路径转换为UPath(支持本地/GCS/S3)
       - 统一dtype字符串到numpy.dtype的转换
    
    使用示例:
        config = OlmoEarthDatasetConfig(
            h5py_dir="/path/to/data",
            training_modalities=["sentinel2", "landsat"],
            dataset_percentage=0.1  # 只用10%数据做实验
        )
        dataset = config.build()
    """
    h5py_dir: str
    training_modalities: list[str]
    dtype: str = "float32"
    normalize: bool = True
    cache_dir: str | None = None
    samples_per_sec: float | None = None
    dataset_percentage: float = 1.0
    seed: int = 0
    apply_cutmix: bool = False
    filter_idx_file: str | None = None

    def get_numpy_dtype(self) -> np.dtype:
        """Get the numpy dtype."""
        if self.dtype == "float16":
            return np.float16
        elif self.dtype == "float32":
            return np.float32
        else:
            raise ValueError(f"Unsupported dtype: {self.dtype}")

    def validate(self) -> None:
        """Validate the configuration and build kwargs.

        Args:
            kwargs: Dictionary of arguments to validate

        Raises:
            ValueError: If any arguments are invalid
        """
        # Validate supported_modalities
        if not isinstance(self.training_modalities, list):
            raise ValueError("training_modalities must be a list")

    @property
    def h5py_dir_upath(self) -> UPath:
        """Get the h5py directory."""
        return UPath(self.h5py_dir)

    @property
    def cache_dir_upath(self) -> UPath:
        """Get the cache directory."""
        return UPath(self.cache_dir)

    def build(self) -> OlmoEarthDataset:
        """Build the dataset."""
        self.validate()
        kwargs = self.as_dict(exclude_none=True, recurse=False)
        kwargs["h5py_dir"] = self.h5py_dir_upath
        kwargs["cache_dir"] = (
            self.cache_dir_upath if self.cache_dir is not None else None
        )
        kwargs["dtype"] = self.get_numpy_dtype()
        logger.info(f"OlmoEarthDataset kwargs: {kwargs}")
        return OlmoEarthDataset(**kwargs)


HeliosSample = _deprecated_class_alias(
    OlmoEarthSample, "helios.data.dataset.HeliosSample"
)
HeliosDataset = _deprecated_class_alias(
    OlmoEarthDataset, "helios.data.dataset.HeliosDataset"
)
HeliosDatasetConfig = _deprecated_class_alias(
    OlmoEarthDatasetConfig, "helios.data.dataset.HeliosDatasetConfig"
)
