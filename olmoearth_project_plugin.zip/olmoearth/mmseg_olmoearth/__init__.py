"""MMSegmentation adapters for OlmoEarth.

This package intentionally keeps ``olmoearth_pretrain`` as an external
runtime dependency and only registers thin OpenMMLab adapters.
"""

from .datasets import *  # noqa: F401,F403
from .hooks import *  # noqa: F401,F403
from .models import *  # noqa: F401,F403

__all__ = []
