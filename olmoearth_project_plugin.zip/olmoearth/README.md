# OlmoEarth MMSegmentation Project Plugin

This project plugin lets MMSegmentation train a semantic segmentation linear probe or fine-tune a full segmentation model on top of an `olmoearth_pretrain` pretrained encoder.

It is designed to be copied to:

```text
mmsegmentation/projects/olmoearth
```

The plugin keeps `olmoearth_pretrain` as an external dependency. It does **not** vendor or reimplement the OlmoEarth model.

## What is included

- `OlmoEarthLinearProbeSegmentor`
- `OlmoEarthBackboneAdapter`
- `OlmoEarthSegDataPreprocessor`
- `OlmoEarthLinearProbeHead`
- `OlmoEarthGeobenchSegDataset`
- `OlmoEarthBackboneFreezeScheduleHook`
- Two Cashew Plant configs:
  - `configs/cashew_plant_frozen_linear_probe.py`
  - `configs/cashew_plant_freeze10_finetune.py`

## Expected pretrained checkpoint format

The adapter loads OlmoEarth weights from a directory containing:

```text
config.json
weights.pth
```

Set this path in the configs:

```python
olmoearth_model_path = 'checkpoints/OlmoEarth-v1-Base'
```

The plugin loads the full OlmoEarth pretrained model through `olmoearth_pretrain.model_loader.load_model_from_path`, then registers only the encoder as the MMSeg backbone. MMSeg checkpoints therefore save the full segmentation network parameters:

```text
OlmoEarth encoder backbone + token adapter state + linear probe head
```

They do not save OlmoEarth's pretraining decoder, target encoder, or optimizer state.

## Data

The included Cashew Plant configs wrap OlmoEarth's GeoBench dataset implementation. Set:

```python
data_root = 'data/geobench'
```

The expected GeoBench layout is:

```text
data/geobench/segmentation_v1.0/m-cashew-plant
```

The wrapper reuses OlmoEarth's existing GeoBench preprocessing, including band imputation, Sentinel-2 L2A band ordering, normalization, timestamp construction, and `MaskedOlmoEarthSample` creation.

## Training

Frozen linear probe:

```bash
torchrun --nproc_per_node=4 tools/train.py \
  projects/olmoearth/configs/cashew_plant_frozen_linear_probe.py
```

Freeze for 10 epochs, then full fine-tune for 40 epochs:

```bash
torchrun --nproc_per_node=4 tools/train.py \
  projects/olmoearth/configs/cashew_plant_freeze10_finetune.py
```

## Notes

1. Use `collate_fn=dict(type='pseudo_collate')` with this plugin. The data preprocessor handles the OlmoEarth multimodal collation.
2. OlmoEarth native ignored labels use `-1`; the dataset wrapper converts them to MMSeg's `ignore_index=255`.
3. `OlmoEarthLinearProbeHead` defaults to a patch-to-pixel projection, mirroring OlmoEarth's native segmentation linear probe more closely than a plain upsampled 1x1 conv.
4. For freeze-then-fine-tune, the model is constructed with the backbone trainable so the optimizer contains backbone parameter groups. The hook freezes it after optimizer construction and unfreezes it at epoch 10.
