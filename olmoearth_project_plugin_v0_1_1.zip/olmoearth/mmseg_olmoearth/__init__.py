"""MMSegmentation adapters for OlmoEarth.

This package intentionally keeps ``olmoearth_pretrain`` as an external
runtime dependency and only registers thin OpenMMLab adapters.
"""

# Must run before importing olmoearth_pretrain/olmo_core on PyTorch builds
# where DeviceMesh is not exported from torch.distributed.
from . import compat as _compat  # noqa: F401

from .datasets import *  # noqa: F401,F403
from .hooks import *  # noqa: F401,F403
from .models import *  # noqa: F401,F403

__all__ = []
