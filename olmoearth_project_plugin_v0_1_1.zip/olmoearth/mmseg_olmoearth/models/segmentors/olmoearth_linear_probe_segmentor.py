"""MMSeg-native segmentor for OlmoEarth linear probing and fine-tuning."""

from __future__ import annotations

from collections.abc import Sequence
from typing import Any

import torch
from torch import Tensor

from mmengine.model import BaseModel
from mmengine.structures import PixelData
from mmseg.registry import MODELS


@MODELS.register_module()
class OlmoEarthLinearProbeSegmentor(BaseModel):
    """Segmentor that connects an OlmoEarth encoder to a linear decode head.

    This model is intentionally MMSeg/MMEngine-native, so DDP, AMP, checkpointing,
    resume, validation, and testing are handled by the standard Runner.
    """

    def __init__(
        self,
        backbone: dict,
        decode_head: dict,
        data_preprocessor: dict | None = None,
        init_cfg: dict | None = None,
    ) -> None:
        super().__init__(data_preprocessor=data_preprocessor, init_cfg=init_cfg)
        self.backbone = MODELS.build(backbone)
        self.decode_head = MODELS.build(decode_head)

    def freeze_backbone(self) -> None:
        if hasattr(self.backbone, 'set_frozen'):
            self.backbone.set_frozen(True)
        else:
            for parameter in self.backbone.parameters():
                parameter.requires_grad = False
            self.backbone.eval()

    def unfreeze_backbone(self) -> None:
        if hasattr(self.backbone, 'set_frozen'):
            self.backbone.set_frozen(False)
        else:
            for parameter in self.backbone.parameters():
                parameter.requires_grad = True
            self.backbone.train()

    def train(self, mode: bool = True) -> 'OlmoEarthLinearProbeSegmentor':
        super().train(mode)
        # The backbone adapter preserves eval mode if it is currently frozen.
        return self

    def extract_feat(self, inputs: Any) -> tuple[Tensor, ...]:
        return self.backbone(inputs)

    def loss(self, inputs: Any, data_samples: Sequence) -> dict[str, Tensor]:
        feats = self.extract_feat(inputs)
        return self.decode_head.loss(feats, data_samples)

    def _forward(self, inputs: Any, data_samples: Sequence | None = None) -> Tensor:
        feats = self.extract_feat(inputs)
        return self.decode_head.predict(feats, data_samples)

    def predict(self, inputs: Any, data_samples: Sequence | None = None) -> Sequence:
        logits = self._forward(inputs, data_samples)
        pred = logits.argmax(dim=1, keepdim=True)
        if data_samples is None:
            return logits
        results = []
        for idx, sample in enumerate(data_samples):
            sample.set_data({
                'seg_logits': PixelData(data=logits[idx]),
                'pred_sem_seg': PixelData(data=pred[idx]),
            })
            results.append(sample)
        return results

    def forward(
        self,
        inputs: Any,
        data_samples: Sequence | None = None,
        mode: str = 'tensor',
    ) -> Any:
        if mode == 'loss':
            if data_samples is None:
                raise ValueError('data_samples is required when mode="loss"')
            return self.loss(inputs, data_samples)
        if mode == 'predict':
            return self.predict(inputs, data_samples)
        if mode == 'tensor':
            return self._forward(inputs, data_samples)
        raise RuntimeError(f'Invalid mode {mode!r}.')
