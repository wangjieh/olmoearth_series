"""Data preprocessor for OlmoEarth MMSeg adapters."""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from typing import Any

import torch
from torch import Tensor
from torch.utils.data._utils.collate import default_collate

from mmengine.model import BaseDataPreprocessor
from mmseg.registry import MODELS

from olmoearth_pretrain.datatypes import MaskedOlmoEarthSample

from ...utils import build_masked_sample_from_dict, collate_olmoearth_inputs


@MODELS.register_module()
class OlmoEarthSegDataPreprocessor(BaseDataPreprocessor):
    """Convert MMSeg batches to ``MaskedOlmoEarthSample``.

    The recommended dataloader collate function for this plugin is
    ``pseudo_collate``. The preprocessor accepts either:

    1. A list of per-sample dictionaries with ``inputs`` and ``data_samples``.
    2. A normal MMSeg-style dictionary with already-collated ``inputs``.
    3. A prebuilt ``MaskedOlmoEarthSample``.

    Args:
        input_layout: Layout used by raw dataset tensors. Use ``'olmoearth'`` for
            tensors already shaped like OlmoEarth ``[H, W, T, C]`` /
            ``[B, H, W, T, C]``. Use ``'btchw'`` for PyTorch-style
            ``[T, C, H, W]`` / ``[B, T, C, H, W]``.
        infer_missing_masks: Create all-ONLINE masks for raw tensors that do not
            include OlmoEarth mask fields.
        default_timestamp: Timestamp used when datasets do not provide one.
        non_blocking: Passed to tensor ``to(device)``.
    """

    def __init__(
        self,
        input_layout: str = 'olmoearth',
        infer_missing_masks: bool = True,
        default_timestamp: Sequence[int] = (1, 6, 2020),
        non_blocking: bool = True,
    ) -> None:
        super().__init__(non_blocking=non_blocking)
        self.input_layout = input_layout
        self.infer_missing_masks = infer_missing_masks
        self.default_timestamp = tuple(default_timestamp)

    def _move_sample(self, sample: MaskedOlmoEarthSample) -> MaskedOlmoEarthSample:
        return sample.to_device(torch.device(self.device), non_blocking=self.non_blocking)

    def _move_data_samples(self, data_samples: Any) -> Any:
        if data_samples is None:
            return None
        if isinstance(data_samples, list):
            for sample in data_samples:
                if hasattr(sample, 'to'):
                    sample.to(self.device)
            return data_samples
        if hasattr(data_samples, 'to'):
            return data_samples.to(self.device)
        return data_samples

    def _collate_from_list(self, data: Sequence[Mapping[str, Any]]) -> dict[str, Any]:
        inputs_list = [item['inputs'] for item in data]
        data_samples = [item.get('data_samples', None) for item in data]
        sample = collate_olmoearth_inputs(
            inputs_list,
            input_layout=self.input_layout,
            infer_missing_masks=self.infer_missing_masks,
            default_timestamp=self.default_timestamp,
        )
        return {'inputs': sample, 'data_samples': data_samples}

    def _collate_from_mapping(self, data: Mapping[str, Any]) -> dict[str, Any]:
        inputs = data.get('inputs')
        data_samples = data.get('data_samples', None)

        if isinstance(inputs, MaskedOlmoEarthSample):
            sample = inputs
        elif isinstance(inputs, Mapping):
            sample = build_masked_sample_from_dict(
                inputs,
                input_layout=self.input_layout,
                infer_missing_masks=self.infer_missing_masks,
                default_timestamp=self.default_timestamp,
            )
        elif isinstance(inputs, list):
            sample = collate_olmoearth_inputs(
                inputs,
                input_layout=self.input_layout,
                infer_missing_masks=self.infer_missing_masks,
                default_timestamp=self.default_timestamp,
            )
        elif isinstance(inputs, Tensor):
            # Backward-compatible single-tensor shortcut. Treat it as Sentinel-2.
            sample = build_masked_sample_from_dict(
                {'sentinel2_l2a': inputs},
                input_layout=self.input_layout,
                infer_missing_masks=self.infer_missing_masks,
                default_timestamp=self.default_timestamp,
            )
        else:
            raise TypeError(f'Unsupported inputs type: {type(inputs)!r}')

        if data_samples is not None and not isinstance(data_samples, list):
            try:
                data_samples = default_collate(data_samples)
            except Exception:
                pass
        return {'inputs': sample, 'data_samples': data_samples}

    def forward(self, data: Any, training: bool = False) -> dict[str, Any]:
        if isinstance(data, (list, tuple)):
            output = self._collate_from_list(data)
        elif isinstance(data, Mapping):
            output = self._collate_from_mapping(data)
        else:
            raise TypeError(f'Unsupported data batch type: {type(data)!r}')

        output['inputs'] = self._move_sample(output['inputs'])
        output['data_samples'] = self._move_data_samples(output.get('data_samples'))
        return output
