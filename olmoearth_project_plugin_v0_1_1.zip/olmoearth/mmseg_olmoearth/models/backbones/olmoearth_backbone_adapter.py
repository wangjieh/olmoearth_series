"""Frozen/fine-tunable OlmoEarth encoder adapter for MMSegmentation."""

from __future__ import annotations

from collections.abc import Iterable
from typing import Any

import torch
from torch import nn

from mmengine.model import BaseModule
from mmseg.registry import MODELS

from olmoearth_pretrain.datatypes import MaskValue, MaskedOlmoEarthSample
from olmoearth_pretrain.model_loader import load_model_from_path
from olmoearth_pretrain.nn.pooling import PoolingType, pool_unmasked_tokens


@MODELS.register_module()
class OlmoEarthBackboneAdapter(BaseModule):
    """Wrap an OlmoEarth pretrained encoder as an MMSeg backbone.

    Args:
        model_path: Directory containing ``config.json`` and ``weights.pth``.
        patch_size: Patch size passed to OlmoEarth encoder.
        pooling_type: Pooling strategy over time/band-set/modality tokens.
        concat_features: Forwarded to OlmoEarth pooling. For segmentation this is
            usually false so the output channel dimension stays stable.
        frozen: If true, set encoder params ``requires_grad=False`` immediately.
        no_grad_when_frozen: If true, frozen forward uses ``torch.no_grad()``.
        load_weights: Whether to load ``weights.pth`` from ``model_path``.
        keep_full_model: Keep the full loaded OlmoEarth model as a private
            attribute. Defaults to false to avoid saving decoder/target-encoder
            parameters in MMSeg checkpoints.
    """

    def __init__(
        self,
        model_path: str,
        patch_size: int = 4,
        pooling_type: str = 'mean',
        concat_features: bool = False,
        frozen: bool = True,
        no_grad_when_frozen: bool = True,
        load_weights: bool = True,
        keep_full_model: bool = False,
        init_cfg: dict | None = None,
    ) -> None:
        super().__init__(init_cfg=init_cfg)
        self.model_path = model_path
        self.patch_size = patch_size
        self.pooling_type = PoolingType(pooling_type)
        self.concat_features = concat_features
        self.no_grad_when_frozen = no_grad_when_frozen
        self.keep_full_model = keep_full_model

        loaded = load_model_from_path(model_path, load_weights=load_weights)
        self._full_model = loaded if keep_full_model else None
        self.encoder = getattr(loaded, 'encoder', loaded)
        self.frozen = False
        self.set_frozen(frozen)

    @staticmethod
    def _has_missing_tokens(sample: MaskedOlmoEarthSample) -> bool:
        for name, value in sample.as_dict(include_nones=False).items():
            if name.endswith('_mask') and value is not None:
                if (value == MaskValue.MISSING.value).any():
                    return True
        return False

    def set_frozen(self, frozen: bool = True) -> None:
        """Freeze or unfreeze the encoder parameters."""
        self.frozen = bool(frozen)
        for parameter in self.encoder.parameters():
            parameter.requires_grad = not self.frozen
        if self.frozen:
            self.encoder.eval()
        else:
            self.encoder.train()

    def train(self, mode: bool = True) -> 'OlmoEarthBackboneAdapter':
        """Preserve eval mode for frozen encoders during ``model.train()``."""
        super().train(mode)
        if self.frozen:
            self.encoder.eval()
        return self

    def trainable_parameters(self) -> Iterable[nn.Parameter]:
        return (p for p in self.parameters() if p.requires_grad)

    def _forward_encoder(self, sample: MaskedOlmoEarthSample) -> torch.Tensor:
        fast_pass = not self._has_missing_tokens(sample)
        output = self.encoder(sample, patch_size=self.patch_size, fast_pass=fast_pass)
        tokens_and_masks = output['tokens_and_masks']
        embeddings = pool_unmasked_tokens(
            tokens_and_masks,
            pooling_type=self.pooling_type,
            spatial_pooling=True,
            concat_features=self.concat_features,
        )

        # Expected default shape from OlmoEarth pooling: [B, H, W, D].
        if embeddings.ndim == 4:
            features = embeddings.permute(0, 3, 1, 2).contiguous()
        elif embeddings.ndim == 5:
            # concat_features=True returns [B, H*W or H, W, N, D] depending on
            # upstream implementation. Favor robust behavior: average modality
            # tokens when a separate modality dimension is present.
            if embeddings.shape[1] == embeddings.shape[2]:
                embeddings = embeddings.mean(dim=-2)
                features = embeddings.permute(0, 3, 1, 2).contiguous()
            else:
                raise ValueError(
                    'Unexpected 5D OlmoEarth embedding shape. Set concat_features=False '
                    f'or add a task-specific adapter. Got {tuple(embeddings.shape)}.'
                )
        else:
            raise ValueError(
                'Expected spatial OlmoEarth embeddings with rank 4, got '
                f'{tuple(embeddings.shape)}.'
            )
        return features

    def forward(self, sample: MaskedOlmoEarthSample) -> tuple[torch.Tensor]:
        if self.frozen and self.no_grad_when_frozen:
            with torch.no_grad():
                features = self._forward_encoder(sample)
        else:
            features = self._forward_encoder(sample)
        return (features,)
