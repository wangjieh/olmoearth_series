"""Linear probing decode head aligned with OlmoEarth segmentation probes."""

from __future__ import annotations

from collections.abc import Sequence

import torch
import torch.nn.functional as F
from einops import rearrange
from torch import Tensor, nn

from mmengine.model import BaseModule
from mmseg.registry import MODELS


@MODELS.register_module()
class OlmoEarthLinearProbeHead(BaseModule):
    """A minimal linear segmentation head for OlmoEarth patch embeddings.

    The default ``patch_to_pixel`` mode mirrors OlmoEarth's native segmentation
    linear probe: each patch embedding predicts a small ``r x r`` grid of logits,
    then logits are rearranged back to image space.

    Args:
        in_channels: OlmoEarth encoder feature dimension.
        num_classes: Number of semantic classes.
        output_pixels_per_side: ``r`` in the patch-to-pixel projection.
        ignore_index: Label value ignored by CE loss and metrics.
        align_corners: Interpolation setting used if logits do not match labels.
        loss_weight: Scalar CE loss weight.
        mode: ``'patch_to_pixel'`` or ``'conv_upsample'``.
    """

    def __init__(
        self,
        num_classes: int,
        in_channels: int | None = None,
        output_pixels_per_side: int = 4,
        ignore_index: int = 255,
        align_corners: bool = True,
        loss_weight: float = 1.0,
        mode: str = 'patch_to_pixel',
        init_cfg: dict | None = None,
    ) -> None:
        super().__init__(init_cfg=init_cfg)
        if mode not in ('patch_to_pixel', 'conv_upsample'):
            raise ValueError("mode must be 'patch_to_pixel' or 'conv_upsample'")
        self.in_channels = in_channels
        self.num_classes = num_classes
        self.output_pixels_per_side = output_pixels_per_side
        self.ignore_index = ignore_index
        self.align_corners = align_corners
        self.loss_weight = loss_weight
        self.mode = mode

        if mode == 'patch_to_pixel':
            out_channels = num_classes * output_pixels_per_side * output_pixels_per_side
        else:
            out_channels = num_classes
        if in_channels is None:
            self.proj = nn.LazyConv2d(out_channels, kernel_size=1)
        else:
            self.proj = nn.Conv2d(in_channels, out_channels, kernel_size=1)

    def _select_feature(self, feats: Tensor | Sequence[Tensor]) -> Tensor:
        if isinstance(feats, Tensor):
            return feats
        if not feats:
            raise ValueError('decode head received an empty feature sequence')
        return feats[0]

    def forward(
        self,
        feats: Tensor | Sequence[Tensor],
        output_size: tuple[int, int] | None = None,
    ) -> Tensor:
        x = self._select_feature(feats)
        logits = self.proj(x)

        if self.mode == 'patch_to_pixel':
            r = self.output_pixels_per_side
            logits = rearrange(
                logits,
                'b (c i j) h w -> b c (h i) (w j)',
                c=self.num_classes,
                i=r,
                j=r,
            )

        if output_size is not None and logits.shape[-2:] != output_size:
            logits = F.interpolate(
                logits,
                size=output_size,
                mode='bilinear',
                align_corners=self.align_corners,
            )
        return logits

    @staticmethod
    def _stack_gt(data_samples: Sequence) -> Tensor:
        labels = []
        for sample in data_samples:
            gt = sample.gt_sem_seg.data
            if gt.ndim == 3 and gt.shape[0] == 1:
                gt = gt.squeeze(0)
            labels.append(gt.long())
        return torch.stack(labels, dim=0)

    def loss(self, feats: Tensor | Sequence[Tensor], data_samples: Sequence) -> dict[str, Tensor]:
        targets = self._stack_gt(data_samples)
        logits = self.forward(feats, output_size=targets.shape[-2:])
        loss = F.cross_entropy(logits, targets, ignore_index=self.ignore_index)
        return {'loss_ce': loss * self.loss_weight}

    def predict(self, feats: Tensor | Sequence[Tensor], data_samples: Sequence | None = None) -> Tensor:
        output_size = None
        if data_samples:
            gt = data_samples[0].gt_sem_seg.data if hasattr(data_samples[0], 'gt_sem_seg') else None
            if gt is not None:
                output_size = tuple(gt.shape[-2:])
            else:
                img_shape = data_samples[0].metainfo.get('img_shape', None)
                if img_shape is not None:
                    output_size = tuple(img_shape[:2])
        return self.forward(feats, output_size=output_size)
