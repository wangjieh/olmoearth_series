"""Compatibility shims for importing OlmoEarth in OpenMMLab environments."""

from __future__ import annotations


def patch_torch_distributed_device_mesh() -> None:
    """Expose ``torch.distributed.DeviceMesh`` when older PyTorch does not.

    Some ``olmo_core``/``olmoearth_pretrain`` versions import
    ``DeviceMesh`` from ``torch.distributed``. Several PyTorch builds expose it
    at ``torch.distributed.device_mesh.DeviceMesh`` instead, and older builds do
    not expose it at all. The import-time failure blocks MMSeg config parsing,
    even when the project only needs OlmoEarth's frozen encoder.

    This shim runs before importing any OlmoEarth modules. It first aliases the
    real class when available; otherwise it installs a small placeholder that is
    sufficient for import-time type annotations. Code paths that genuinely need
    distributed tensor placement should still use a PyTorch version with a real
    DeviceMesh implementation.
    """

    try:
        import torch.distributed as dist
    except Exception:
        return

    if hasattr(dist, 'DeviceMesh'):
        return

    try:
        from torch.distributed.device_mesh import DeviceMesh  # type: ignore
    except Exception:
        class DeviceMesh:  # type: ignore[no-redef]
            def __init__(self, *args, **kwargs) -> None:
                raise RuntimeError(
                    'torch.distributed.DeviceMesh is not available in this '
                    'PyTorch build. This placeholder only unblocks imports; '
                    'install a newer PyTorch version if DeviceMesh execution is required.'
                )

    setattr(dist, 'DeviceMesh', DeviceMesh)


patch_torch_distributed_device_mesh()
