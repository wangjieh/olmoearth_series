"""Utilities for converting MMSeg batches to OlmoEarth samples."""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from typing import Any

import torch
from torch import Tensor
from torch.utils.data._utils.collate import default_collate

from olmoearth_pretrain.datatypes import MaskValue, MaskedOlmoEarthSample


MASK_SUFFIX = '_mask'
TIMESTAMPS = 'timestamps'
LATLON = 'latlon'


def _is_tensor_like(x: Any) -> bool:
    return isinstance(x, Tensor)


def _to_device(value: Any, device: torch.device | None, non_blocking: bool = True) -> Any:
    if isinstance(value, Tensor):
        return value.to(device=device, non_blocking=non_blocking)
    return value


def _convert_layout(
    key: str,
    value: Tensor,
    input_layout: str,
) -> Tensor:
    """Convert a modality tensor to OlmoEarth's channels-last layout.

    OlmoEarth spatial modalities use ``[B, H, W, T, C]``. MMSeg/PyTorch
    datasets often use ``[B, T, C, H, W]``. The ``input_layout`` option controls
    the conversion for non-mask modality tensors. Mask tensors are assumed to be
    already in OlmoEarth layout when supplied by an OlmoEarth dataset wrapper.
    """
    if key == TIMESTAMPS or key == LATLON or key.endswith(MASK_SUFFIX):
        return value

    if input_layout in ('olmoearth', 'channels_last'):
        return value

    if input_layout in ('btchw', 'channels_first_time'):
        if value.ndim == 5:  # [B, T, C, H, W] -> [B, H, W, T, C]
            return value.permute(0, 3, 4, 1, 2).contiguous()
        if value.ndim == 4:  # [B, C, H, W] static -> [B, H, W, 1, C]
            return value.permute(0, 2, 3, 1).unsqueeze(3).contiguous()
        return value

    if input_layout in ('bthwc', 'time_channels_last'):
        if value.ndim == 5:  # [B, T, H, W, C] -> [B, H, W, T, C]
            return value.permute(0, 2, 3, 1, 4).contiguous()
        if value.ndim == 4:  # [B, H, W, C] static -> [B, H, W, 1, C]
            return value.unsqueeze(3).contiguous()
        return value

    raise ValueError(
        f'Unsupported input_layout={input_layout!r}. Expected one of '
        "'olmoearth', 'channels_last', 'btchw', 'channels_first_time', "
        "'bthwc', or 'time_channels_last'."
    )


def _infer_mask_from_value(value: Tensor) -> Tensor:
    """Create an ONLINE_ENCODER mask matching all non-feature dimensions.

    This fallback is useful for external MMSeg datasets that provide raw tensors
    but not OlmoEarth mask fields. It assumes no missing data.
    """
    if value.ndim == 5:  # [B, H, W, T, C]
        shape = value.shape[:-1] + (1,)
    elif value.ndim == 3:  # [B, T, C], time-only modality
        shape = value.shape[:-1] + (1,)
    elif value.ndim == 2:  # [B, C], e.g. latlon-like
        shape = value.shape
    else:
        shape = value.shape
    return torch.full(
        shape,
        fill_value=MaskValue.ONLINE_ENCODER.value,
        dtype=torch.long,
        device=value.device,
    )


def build_masked_sample_from_dict(
    inputs: Mapping[str, Any],
    *,
    input_layout: str = 'olmoearth',
    infer_missing_masks: bool = True,
    default_timestamp: Sequence[int] = (1, 6, 2020),
) -> MaskedOlmoEarthSample:
    """Build a ``MaskedOlmoEarthSample`` from a batched multimodal dict.

    Args:
        inputs: Batched multimodal dictionary. Tensors may be in OlmoEarth layout
            or a supported channels-first layout.
        input_layout: Layout for raw spatial modality tensors.
        infer_missing_masks: If true, create all-ONLINE masks for modalities that
            do not provide ``<modality>_mask``.
        default_timestamp: Used when no timestamps are supplied. The convention
            follows OlmoEarth's ``[day, month, year]`` timestamp vector.
    """
    sample_dict: dict[str, Any] = {}
    for key, value in inputs.items():
        if value is None:
            continue
        if _is_tensor_like(value):
            sample_dict[key] = _convert_layout(key, value, input_layout)
        else:
            sample_dict[key] = value

    if TIMESTAMPS not in sample_dict:
        batch_size = None
        time_steps = 1
        for key, value in sample_dict.items():
            if key.endswith(MASK_SUFFIX) or not isinstance(value, Tensor):
                continue
            batch_size = value.shape[0]
            if value.ndim == 5:
                time_steps = value.shape[3]
            elif value.ndim == 3 and key != LATLON:
                time_steps = value.shape[1]
            break
        if batch_size is None:
            raise ValueError('Could not infer batch size to create timestamps.')
        ts = torch.tensor(default_timestamp, dtype=torch.long)
        sample_dict[TIMESTAMPS] = ts.view(1, 1, 3).repeat(batch_size, time_steps, 1)

    if infer_missing_masks:
        field_names = set(MaskedOlmoEarthSample._fields)
        for key, value in list(sample_dict.items()):
            if (
                key in (TIMESTAMPS,)
                or key.endswith(MASK_SUFFIX)
                or not isinstance(value, Tensor)
            ):
                continue
            mask_key = f'{key}{MASK_SUFFIX}'
            if mask_key in field_names and mask_key not in sample_dict:
                sample_dict[mask_key] = _infer_mask_from_value(value)

    # Drop unknown keys rather than failing on MMSeg-specific metadata.
    allowed = set(MaskedOlmoEarthSample._fields)
    sample_dict = {k: v for k, v in sample_dict.items() if k in allowed}
    return MaskedOlmoEarthSample(**sample_dict)


def collate_olmoearth_inputs(
    samples: Sequence[Mapping[str, Any] | MaskedOlmoEarthSample],
    *,
    input_layout: str = 'olmoearth',
    infer_missing_masks: bool = True,
    default_timestamp: Sequence[int] = (1, 6, 2020),
) -> MaskedOlmoEarthSample:
    """Collate a list of per-sample OlmoEarth dictionaries into a sample."""
    if len(samples) == 0:
        raise ValueError('Cannot collate an empty batch.')

    first = samples[0]
    if isinstance(first, MaskedOlmoEarthSample):
        collated = default_collate([s.as_dict(include_nones=False) for s in samples])
        return MaskedOlmoEarthSample(**collated)

    collated = default_collate(list(samples))
    return build_masked_sample_from_dict(
        collated,
        input_layout=input_layout,
        infer_missing_masks=infer_missing_masks,
        default_timestamp=default_timestamp,
    )
