"""Lightweight task config helpers that avoid importing OlmoEarth eval datasets.

Importing ``olmoearth_pretrain.evals.datasets.configs`` triggers the package
``olmoearth_pretrain.evals.datasets.__init__`` first, which imports every eval
Dataset and may pull in ``olmo_core.data``. On some OpenMMLab environments this
fails during MMSeg config parsing. This module keeps the common GeoBench
segmentation constants local and falls back to the upstream config only at
runtime when a task is unknown.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any


@dataclass
class LightEvalDatasetConfig:
    task_type: str
    imputes: list[tuple[str, str]]
    num_classes: int
    is_multilabel: bool
    supported_modalities: list[str]
    height_width: int | None = None
    timeseries: bool = False

    def to_dict(self) -> dict[str, Any]:
        return {
            'task_type': self.task_type,
            'imputes': self.imputes,
            'num_classes': self.num_classes,
            'is_multilabel': self.is_multilabel,
            'supported_modalities': self.supported_modalities,
            'height_width': self.height_width,
            'timeseries': self.timeseries,
        }


# Local subset of olmoearth_pretrain.evals.datasets.configs.DATASET_TO_CONFIG.
# This avoids heavy imports during custom_imports. Extend here when adding a new
# commonly used MMSeg config; unknown tasks fall back to upstream at runtime.
LOCAL_DATASET_CONFIGS: dict[str, LightEvalDatasetConfig] = {
    'm-cashew-plant': LightEvalDatasetConfig(
        task_type='segmentation',
        imputes=[('11 - SWIR', '10 - SWIR - Cirrus')],
        num_classes=7,
        is_multilabel=False,
        height_width=256,
        supported_modalities=['sentinel2_l2a'],
    ),
    'm-sa-crop-type': LightEvalDatasetConfig(
        task_type='segmentation',
        imputes=[('11 - SWIR', '10 - SWIR - Cirrus')],
        num_classes=10,
        is_multilabel=False,
        height_width=256,
        supported_modalities=['sentinel2_l2a'],
    ),
    'mados': LightEvalDatasetConfig(
        task_type='segmentation',
        imputes=[
            ('05 - Vegetation Red Edge', '06 - Vegetation Red Edge'),
            ('08A - Vegetation Red Edge', '09 - Water vapour'),
            ('11 - SWIR', '10 - SWIR - Cirrus'),
        ],
        num_classes=15,
        is_multilabel=False,
        height_width=80,
        supported_modalities=['sentinel2_l2a'],
    ),
    'sen1floods11': LightEvalDatasetConfig(
        task_type='segmentation',
        imputes=[],
        num_classes=2,
        is_multilabel=False,
        height_width=64,
        supported_modalities=['sentinel1'],
    ),
    'pastis': LightEvalDatasetConfig(
        task_type='segmentation',
        imputes=[],
        num_classes=20,
        is_multilabel=False,
        height_width=64,
        supported_modalities=['sentinel2_l2a', 'sentinel1'],
        timeseries=True,
    ),
    'pastis128': LightEvalDatasetConfig(
        task_type='segmentation',
        imputes=[],
        num_classes=20,
        is_multilabel=False,
        height_width=128,
        supported_modalities=['sentinel2_l2a', 'sentinel1'],
        timeseries=True,
    ),
}


def dataset_to_config_light(dataset: str) -> LightEvalDatasetConfig:
    if dataset in LOCAL_DATASET_CONFIGS:
        return LOCAL_DATASET_CONFIGS[dataset]

    # Runtime fallback for tasks not covered above. At this point the user is
    # actually constructing a dataset, so importing the upstream dataset package
    # is acceptable and produces a more informative dependency error if missing.
    from olmoearth_pretrain.evals.datasets.configs import dataset_to_config

    cfg = dataset_to_config(dataset)
    return LightEvalDatasetConfig(
        task_type=getattr(cfg.task_type, 'value', str(cfg.task_type)),
        imputes=list(cfg.imputes),
        num_classes=cfg.num_classes,
        is_multilabel=cfg.is_multilabel,
        supported_modalities=list(cfg.supported_modalities),
        height_width=cfg.height_width,
        timeseries=cfg.timeseries,
    )
