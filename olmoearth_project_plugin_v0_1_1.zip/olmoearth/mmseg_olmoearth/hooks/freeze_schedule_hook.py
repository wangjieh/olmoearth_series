"""Hooks for freezing and unfreezing OlmoEarth backbones."""

from __future__ import annotations

from typing import Any

from mmengine.hooks import Hook
from mmengine.registry import HOOKS
from mmengine.logging import print_log


def _unwrap_model(model: Any) -> Any:
    return model.module if hasattr(model, 'module') else model


@HOOKS.register_module()
class OlmoEarthBackboneFreezeScheduleHook(Hook):
    """Freeze backbone for the first N epochs, then unfreeze.

    The hook freezes after the optimizer has been constructed, so the optimizer
    can still contain backbone parameter groups and update them after unfreeze.

    Args:
        frozen_epochs: Number of initial epochs with the backbone frozen. If 0,
            the backbone is left trainable from the start.
        verbose: Log freeze/unfreeze events.
    """

    priority = 'NORMAL'

    def __init__(self, frozen_epochs: int = 10, verbose: bool = True) -> None:
        self.frozen_epochs = int(frozen_epochs)
        self.verbose = verbose
        self._is_frozen: bool | None = None

    def _set_frozen(self, runner: Any, frozen: bool) -> None:
        model = _unwrap_model(runner.model)
        if frozen and hasattr(model, 'freeze_backbone'):
            model.freeze_backbone()
        elif not frozen and hasattr(model, 'unfreeze_backbone'):
            model.unfreeze_backbone()
        else:
            backbone = getattr(model, 'backbone', None)
            if backbone is None:
                raise AttributeError('Model has no backbone or freeze/unfreeze methods.')
            for parameter in backbone.parameters():
                parameter.requires_grad = not frozen
            backbone.eval() if frozen else backbone.train()
        self._is_frozen = frozen
        if self.verbose:
            state = 'frozen' if frozen else 'unfrozen'
            print_log(f'OlmoEarth backbone is now {state}.', logger='current')

    def before_train(self, runner: Any) -> None:
        if self.frozen_epochs > 0:
            self._set_frozen(runner, True)
        else:
            self._set_frozen(runner, False)

    def before_train_epoch(self, runner: Any) -> None:
        should_freeze = runner.epoch < self.frozen_epochs
        if self._is_frozen is None or self._is_frozen != should_freeze:
            self._set_frozen(runner, should_freeze)
