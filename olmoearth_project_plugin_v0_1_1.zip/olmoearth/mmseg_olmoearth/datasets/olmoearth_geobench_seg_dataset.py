"""MMSeg dataset wrapper for OlmoEarth/GeoBench segmentation datasets."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import torch
from mmengine.structures import PixelData
from mmseg.registry import DATASETS
from mmseg.structures import SegDataSample
from torch.utils.data import Dataset

from ..utils.task_config import dataset_to_config_light


@DATASETS.register_module()
class OlmoEarthGeobenchSegDataset(Dataset):
    """Wrap ``olmoearth_pretrain.evals.datasets.GeobenchDataset`` for MMSeg.

    The wrapped OlmoEarth dataset already performs GeoBench band imputation,
    OlmoEarth band reordering, normalization, timestamp construction, and
    ``MaskedOlmoEarthSample`` creation. This wrapper converts the sample to an
    MMSeg-style dictionary while keeping the OlmoEarth multimodal fields intact.

    Args:
        geobench_dir: Root GeoBench directory.
        dataset: GeoBench task name, e.g. ``'m-cashew-plant'``.
        split: ``'train'``, ``'valid'`` or ``'test'``.
        label_fraction: GeoBench label fraction partition.
        norm_stats_from_pretrained: Forwarded to OlmoEarth dataset.
        norm_method: Forwarded to OlmoEarth dataset.
        ignore_index: MMSeg ignore index. OlmoEarth native labels use ``-1`` for
            ignored pixels; this wrapper converts ``-1`` to ``ignore_index``.
        metainfo: Optional MMSeg dataset metainfo override.
    """

    METAINFO = {
        'classes': tuple(f'class_{i}' for i in range(7)),
        'palette': [
            [0, 0, 0],
            [128, 0, 0],
            [0, 128, 0],
            [128, 128, 0],
            [0, 0, 128],
            [128, 0, 128],
            [0, 128, 128],
        ],
    }

    def __init__(
        self,
        geobench_dir: str,
        dataset: str = 'm-cashew-plant',
        split: str = 'train',
        label_fraction: float = 1.0,
        norm_stats_from_pretrained: bool = False,
        norm_method: str = 'norm_no_clip_2_std',
        ignore_index: int = 255,
        metainfo: dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> None:
        super().__init__()
        self.geobench_dir = Path(geobench_dir)
        self.dataset_name = dataset
        self.split = split
        self.ignore_index = ignore_index
        self.config = dataset_to_config_light(dataset)
        if self.config.height_width is None:
            raise ValueError(f'{dataset} is not a dense segmentation/regression task.')

        # Lazy import to keep plugin importable before GeoBench/OlmoEarth datasets are installed.
        # The package-level compat shim has already patched DeviceMesh if needed.
        from olmoearth_pretrain.evals.datasets.geobench_dataset import GeobenchDataset

        self.inner = GeobenchDataset(
            geobench_dir=self.geobench_dir,
            dataset=dataset,
            split=split,
            label_fraction=label_fraction,
            norm_stats_from_pretrained=norm_stats_from_pretrained,
            norm_method=norm_method,
        )
        classes = tuple(f'class_{i}' for i in range(self.config.num_classes))
        palette = self.METAINFO['palette'][: self.config.num_classes]
        if len(palette) < self.config.num_classes:
            palette = palette + [[(37 * i) % 256, (17 * i) % 256, (97 * i) % 256] for i in range(len(palette), self.config.num_classes)]
        self._metainfo = {
            'classes': classes,
            'palette': palette,
            'dataset_name': dataset,
            'ignore_index': ignore_index,
            'height_width': self.config.height_width,
            'num_classes': self.config.num_classes,
        }
        if metainfo:
            self._metainfo.update(metainfo)

    @property
    def metainfo(self) -> dict[str, Any]:
        return self._metainfo

    def __len__(self) -> int:
        return len(self.inner)

    def __getitem__(self, idx: int) -> dict[str, Any]:
        masked_sample, target = self.inner[idx]
        if not isinstance(target, torch.Tensor):
            target = torch.as_tensor(target)
        target = target.long()
        target = target.clone()
        target[target < 0] = self.ignore_index

        data_sample = SegDataSample()
        data_sample.gt_sem_seg = PixelData(data=target.unsqueeze(0))
        h, w = target.shape[-2:]
        data_sample.set_metainfo({
            'img_shape': (h, w),
            'ori_shape': (h, w),
            'pad_shape': (h, w),
            'sample_idx': idx,
            'dataset_name': self.dataset_name,
        })

        return {
            'inputs': masked_sample.as_dict(include_nones=False),
            'data_samples': data_sample,
        }
