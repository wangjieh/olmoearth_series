"""OlmoEarth project plugin for MMSegmentation.

Place this directory under ``mmsegmentation/projects/`` and import it with
``custom_imports = dict(imports=['projects.olmoearth.mmseg_olmoearth'])``.
"""

from . import mmseg_olmoearth  # noqa: F401
