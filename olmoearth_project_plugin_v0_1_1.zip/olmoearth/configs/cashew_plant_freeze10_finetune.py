"""Cashew Plant freeze-then-fine-tune config with OlmoEarth + MMSeg.

Training policy:
- Epoch 0-9: freeze OlmoEarth encoder, train linear decode head.
- Epoch 10-49: unfreeze OlmoEarth encoder, fine-tune full segmentation network.

Edit ``data_root`` and ``olmoearth_model_path`` before running.
"""

custom_imports = dict(
    imports=['projects.olmoearth.mmseg_olmoearth'],
    allow_failed_imports=False,
)

# -----------------------------------------------------------------------------
# User paths
# -----------------------------------------------------------------------------
data_root = 'data/geobench'  # contains segmentation_v1.0/m-cashew-plant
olmoearth_model_path = 'checkpoints/OlmoEarth-v1-Base'  # config.json + weights.pth
work_dir = './work_dirs/olmoearth_cashew_plant_freeze10_finetune'

# -----------------------------------------------------------------------------
# Dataset/task constants
# -----------------------------------------------------------------------------
dataset_type = 'OlmoEarthGeobenchSegDataset'
num_classes = 7
ignore_index = 255
height_width = 256
batch_size = 2
num_workers = 2

model = dict(
    type='OlmoEarthLinearProbeSegmentor',
    data_preprocessor=dict(
        type='OlmoEarthSegDataPreprocessor',
        input_layout='olmoearth',
        infer_missing_masks=True,
    ),
    backbone=dict(
        type='OlmoEarthBackboneAdapter',
        model_path=olmoearth_model_path,
        patch_size=4,
        pooling_type='mean',
        concat_features=False,
        # Keep trainable at construction time so the optimizer includes backbone
        # params. The hook below freezes it after optimizer construction, then
        # unfreezes at epoch 10.
        frozen=False,
        no_grad_when_frozen=True,
        load_weights=True,
    ),
    decode_head=dict(
        type='OlmoEarthLinearProbeHead',
        in_channels=None,
        num_classes=num_classes,
        output_pixels_per_side=4,
        ignore_index=ignore_index,
        mode='patch_to_pixel',
        align_corners=True,
    ),
)

train_dataloader = dict(
    batch_size=batch_size,
    num_workers=num_workers,
    persistent_workers=True,
    sampler=dict(type='DefaultSampler', shuffle=True),
    collate_fn=dict(type='pseudo_collate'),
    dataset=dict(
        type=dataset_type,
        geobench_dir=data_root,
        dataset='m-cashew-plant',
        split='train',
        label_fraction=1.0,
        norm_stats_from_pretrained=False,
        norm_method='norm_no_clip_2_std',
        ignore_index=ignore_index,
    ),
)

val_dataloader = dict(
    batch_size=batch_size,
    num_workers=num_workers,
    persistent_workers=True,
    sampler=dict(type='DefaultSampler', shuffle=False),
    collate_fn=dict(type='pseudo_collate'),
    dataset=dict(
        type=dataset_type,
        geobench_dir=data_root,
        dataset='m-cashew-plant',
        split='valid',
        label_fraction=1.0,
        norm_stats_from_pretrained=False,
        norm_method='norm_no_clip_2_std',
        ignore_index=ignore_index,
    ),
)

test_dataloader = dict(
    batch_size=batch_size,
    num_workers=num_workers,
    persistent_workers=True,
    sampler=dict(type='DefaultSampler', shuffle=False),
    collate_fn=dict(type='pseudo_collate'),
    dataset=dict(
        type=dataset_type,
        geobench_dir=data_root,
        dataset='m-cashew-plant',
        split='test',
        label_fraction=1.0,
        norm_stats_from_pretrained=False,
        norm_method='norm_no_clip_2_std',
        ignore_index=ignore_index,
    ),
)

val_evaluator = dict(type='IoUMetric', iou_metrics=['mIoU'])
test_evaluator = val_evaluator

train_cfg = dict(type='EpochBasedTrainLoop', max_epochs=50, val_interval=5)
val_cfg = dict(type='ValLoop')
test_cfg = dict(type='TestLoop')

# Head lr is 1e-3; backbone lr is 1e-5 via lr_mult=0.01.
optim_wrapper = dict(
    type='OptimWrapper',
    optimizer=dict(type='AdamW', lr=1e-3, weight_decay=0.01),
    paramwise_cfg=dict(
        custom_keys={
            'backbone': dict(lr_mult=0.01, decay_mult=1.0),
            'decode_head': dict(lr_mult=1.0, decay_mult=1.0),
        }
    ),
    clip_grad=dict(max_norm=1.0, norm_type=2),
)

param_scheduler = [
    dict(type='LinearLR', start_factor=1e-3, by_epoch=True, begin=0, end=5),
    dict(type='CosineAnnealingLR', T_max=45, eta_min=1e-6, by_epoch=True, begin=5, end=50),
]

default_scope = 'mmseg'

default_hooks = dict(
    timer=dict(type='IterTimerHook'),
    logger=dict(type='LoggerHook', interval=20, log_metric_by_epoch=True),
    param_scheduler=dict(type='ParamSchedulerHook'),
    checkpoint=dict(
        type='CheckpointHook',
        by_epoch=True,
        interval=5,
        save_best='mIoU',
        rule='greater',
        max_keep_ckpts=3,
    ),
    sampler_seed=dict(type='DistSamplerSeedHook'),
    visualization=dict(type='SegVisualizationHook', draw=False),
)

custom_hooks = [
    dict(type='OlmoEarthBackboneFreezeScheduleHook', frozen_epochs=10, verbose=True),
]

env_cfg = dict(
    cudnn_benchmark=True,
    mp_cfg=dict(mp_start_method='fork', opencv_num_threads=0),
    dist_cfg=dict(backend='nccl'),
)

vis_backends = [dict(type='LocalVisBackend')]
visualizer = dict(type='SegLocalVisualizer', vis_backends=vis_backends, name='visualizer')
log_processor = dict(by_epoch=True)
log_level = 'INFO'
load_from = None
resume = False
