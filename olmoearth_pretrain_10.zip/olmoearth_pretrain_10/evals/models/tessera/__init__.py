"""Tessera model integration."""
